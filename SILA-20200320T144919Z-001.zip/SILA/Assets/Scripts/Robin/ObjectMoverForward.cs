﻿public class AssignedBuilds
{
	Build[] builds;
}

public class Build
{

}